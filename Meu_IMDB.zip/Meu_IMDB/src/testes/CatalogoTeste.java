package testes;

import catalogo.Catalogo;

public class CatalogoTeste {
	public static void main(String[] args) {
		Catalogo c1 = new Catalogo();
		c1.adicionaObras();
		System.out.println("Quantidade de obras no catálogo: "+c1.getQuantObras());
		System.out.println("\nCódigos das obras do catálogo: ");
		c1.mostraCodigos();
		System.out.println("\nImprimindo todos os filmes do catálogo: ");
		c1.mostraFilmes();
		System.out.println("\nImprimindo todas as séries do catálogo: ");
		c1.mostraSeries();
		System.out.println("\nRemovendo uma obra pelo seu código: ");
		c1.removeObra(1);
		System.out.println("\nAtualizando a nota de uma obra pelo código: ");
		c1.atualizaNota(2, 9.1);
	}
}
