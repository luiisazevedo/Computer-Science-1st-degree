package catalogo;

public class Obra {
	private int codigo, ano;
	private String nomeObra, diretor, atores;
	private TipoObra tipo;
	private double nota; 
	
	public Obra(int codigo, int ano, String nomeObra, String diretor, String atores, TipoObra tipo, double nota) {
		this.codigo = codigo;
		this.ano = ano;
		this.nomeObra = nomeObra;
		this.diretor = diretor;
		this.atores = atores;
		this.tipo = tipo;
		this.nota = nota;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public int getAno() {
		return ano;
	}

	public void setAno(int ano) {
		this.ano = ano;
	}

	public String getNomeObra() {
		return nomeObra;
	}

	public void setNomeObra(String nomeObra) {
		this.nomeObra = nomeObra;
	}

	public String getDiretor() {
		return diretor;
	}

	public void setDiretor(String diretor) {
		this.diretor = diretor;
	}

	public String getAtores() {
		return atores;
	}

	public void setAtores(String atores) {
		this.atores = atores;
	}

	public TipoObra getTipo() {
		return tipo;
	}

	public void setTipo(TipoObra tipo) {
		this.tipo = tipo;
	}

	public double getNota() {
		return nota;
	}

	public void setNota(double nota) {
		this.nota = nota;
	}	
}
