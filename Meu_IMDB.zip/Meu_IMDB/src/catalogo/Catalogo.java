package catalogo;

import java.util.ArrayList;
import java.util.List;

public class Catalogo {
	private int quantObras;
	private List<Obra> catalogo;
	
	public Catalogo() {
		catalogo = new ArrayList<Obra>();
		this.quantObras = 0;
	}
	
	public void adicionaObras() {
		catalogo.add(new Obra(1, 2002, "Cidade de Deus", "Fernando Meirelles", 
				"Alexandre Rodrigues, Leandro Firmino, Douglas Silva", TipoObra.FILME, 8.6));
		catalogo.add(new Obra(2, 2012, "Django Livre", "Quentin Tarantino",
				"Jamie Foxx, Leonardo DiCaprio, Christoph Waltz", TipoObra.FILME, 8.5 ));
		catalogo.add(new Obra(3, 1989, "Os Simpsons", "James L. Brooks",
				"Dan Castellaneta, Nancy Cartwright, Julie Kavner", TipoObra.SERIE, 8.7));
		catalogo.add(new Obra(4, 2017, "Dark", "Baran bo Odar",
				"Louis Hofmann, Karoline Eichhorn, Lisa Vicari", TipoObra.SERIE, 8.7));
		catalogo.add(new Obra(5, 2008, "Batman: O Cavaleiro das Trevas", "Christopher Nolan",
				"Christian Bale, Heath Ledger, Aaron Eckhart", TipoObra.FILME, 9.0));
	}
	
	public boolean removeObra(int codigo) {
	    if (catalogo != null) {
	        for (int i = 0; i < catalogo.size(); i++) {
	            Obra obra = catalogo.get(i);
	            if (obra != null && obra.getCodigo() == codigo) {
	                catalogo.remove(i); 
	                System.out.println(obra.getNomeObra()+" foi removido com sucesso!");
	                return true;
	            }
	        }
	    }
	    System.out.println("Não foi possível remover a obra desejada");
	    return false;
	}
	
	public boolean atualizaNota(int codigo, double nota) {
		if(catalogo != null) {
			for(int i = 0; i < catalogo.size(); i++) {
				Obra obra = catalogo.get(i);
				if(obra != null && obra.getCodigo() == codigo) {
					obra.setNota(nota);
					System.out.println(obra.getNomeObra()+" teve a nota atualizada.");
					return true;
				}
			}
		}
		System.out.println("Não foi possível atualizar a nota");
		return false;
	}
	
	public void mostraCodigos() {
		for(int i = 0; i < catalogo.size(); i++) {
			System.out.println(catalogo.get(i).getNomeObra()+" = "+catalogo.get(i).getCodigo());
		}
	}
	
	public void mostraFilmes() {
		for(Obra obra : catalogo) {
			if(obra != null && obra.getTipo() == TipoObra.FILME) {
				tempo();
				System.out.println("Filme: "+'"'+obra.getNomeObra()+'"');
				
			}
		}
	}
	
	public void mostraSeries() {
		for(Obra obra : catalogo) {
			if(obra != null && obra.getTipo() == TipoObra.SERIE) {
				tempo();
				System.out.println("Série: "+'"'+obra.getNomeObra()+'"');
			}
		}
	}
	
	private void tempo() {
		try {
			Thread.sleep(500);
		} catch (Exception e) {}
	}
	
	public int getQuantObras() {
		return catalogo.size();
	}

	public List<Obra> getCatalogo() {
		return catalogo;
	}

	public void setCatalogo(List<Obra> catalogo) {
		this.catalogo = catalogo;
	}
}
