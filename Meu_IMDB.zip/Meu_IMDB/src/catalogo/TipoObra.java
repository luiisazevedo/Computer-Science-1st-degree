package catalogo;

public enum TipoObra {
	SERIE, FILME;
}
